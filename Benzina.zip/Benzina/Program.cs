﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        StazioneDiServizio stazione = new StazioneDiServizio("Stazione A", "Via Roma 1");

        Distributore d1 = new Distributore("DS001", 1000, 1000);
        Distributore d2 = new Distributore("DS002", 500, 500);

        stazione.AggiungiDistributore(d1);
        stazione.AggiungiDistributore(d2);

        d1.ImpostaPrezzo(2);
        d2.ImpostaPrezzo(5);

        d1.AggiungiDenaro(100);
        d2.AggiungiDenaro(100);
        float erogato1 = d1.ErogaBenzina();
        float erogato2 = d2.ErogaBenzina();
        Console.WriteLine("Benzina erogata dal distributore 1 (seriale: " + d1.NumeroSeriale + "): " + erogato1 + " litri");
        Console.WriteLine("Benzina erogata dal distributore 2 (seriale: " + d2.NumeroSeriale + "): " + erogato2 + " litri");
        stazione.RiempiBenzina(200);
        stazione.ResetPrezzo(3);
        Console.WriteLine("Prezzo benzina aggiornato a 3 euro per tutti i distributori.");
        Console.ReadLine();
    }
}

class Distributore
{
    private string numeroSeriale;
    private float capacitaMassima;
    private float livelloCorrente;
    private float denaroCaricato;
    private float prezzoAlLitro;

    public string NumeroSeriale
    {
        get { return numeroSeriale; }
    }

    public Distributore(string numeroSeriale, float capacitaMassima, float livelloIniziale)
    {
        this.numeroSeriale = numeroSeriale;
        this.capacitaMassima = capacitaMassima;
        this.livelloCorrente = livelloIniziale;
        this.denaroCaricato = 0;
        this.prezzoAlLitro = 0;
    }

    public void ImpostaPrezzo(float prezzo) { prezzoAlLitro = prezzo; }
    public void AggiungiDenaro(float quantita) { if (denaroCaricato + quantita <= 100) denaroCaricato += quantita; }
    public float ErogaBenzina()
    {
        float litriErogati = denaroCaricato / prezzoAlLitro;
        if (litriErogati > livelloCorrente) litriErogati = livelloCorrente;
        livelloCorrente -= litriErogati;
        denaroCaricato = 0;
        return litriErogati;
    }
}

class StazioneDiServizio
{
    private string nome;
    private string indirizzo;
    private List<Distributore> distributori;

    public StazioneDiServizio(string nome, string indirizzo)
    {
        this.nome = nome;
        this.indirizzo = indirizzo;
        this.distributori = new List<Distributore>();
    }

    public void AggiungiDistributore(Distributore distributore) { distributori.Add(distributore); }
    public void RiempiBenzina(float quantita)
    {
        foreach (var distributore in distributori)
        {
            distributore.AggiungiDenaro(quantita); 
        }
    }
    public void ResetPrezzo(float prezzo)
    {
        foreach (var distributore in distributori)
        {
            distributore.ImpostaPrezzo(prezzo);
        }
    }
}
